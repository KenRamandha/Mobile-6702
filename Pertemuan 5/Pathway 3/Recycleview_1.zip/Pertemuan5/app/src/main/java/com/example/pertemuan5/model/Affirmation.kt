package com.example.pertemuan5.model

data class Affirmation(val stringResourceId: Int)